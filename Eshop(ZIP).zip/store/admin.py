from django.contrib import admin
from store.models import Product
from store.models import Category , Customer , Order


# Register your models here.

class AdminProduct(admin.ModelAdmin):
    list_display = ['name','price','category','discription','image']

class AdminCategory(admin.ModelAdmin):
    list_display = ['name']

class AdimnCustomer(admin.ModelAdmin):
    list_display = ['First_name','Last_name','Ph_number','Email','Password']


admin.site.register(Product,AdminProduct)
admin.site.register(Category,AdminCategory)
admin.site.register(Customer,AdimnCustomer)
admin.site.register(Order)