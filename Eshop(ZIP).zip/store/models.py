from django.db import models
import datetime

# Create your models here.

class Category(models.Model):
    name= models.CharField(max_length=50)

    def __str__(self):
        return self.name

class Product(models.Model):
    category=models.ForeignKey(Category,on_delete=models.CASCADE)
    name= models.CharField(max_length=50)
    price=models.IntegerField(default=0)
    discription=models.CharField(max_length=200,default='')
    image=models.ImageField(upload_to='upload/store/')

    def __str__(self):
        return self.name

class Customer(models.Model):
    First_name=models.CharField(max_length=50)
    Last_name=models.CharField(max_length=50)
    Ph_number=models.IntegerField()
    Email=models.EmailField()
    Password=models.CharField(max_length=50)

    def __str__(self):
        return self.First_name

class Order(models.Model):
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    quantity=models.IntegerField()
    price=models.IntegerField()
    address=models.CharField(max_length=100)
    phone=models.CharField(max_length=15)
    date=models.DateField(default=datetime.datetime.today)
    status=models.BooleanField(default=False)