

from store.views import index ,signup,login ,logout,cart,checkout,order
from django.urls import path


urlpatterns = [
    path('',index),
    path('signup/',signup),
    path('login/',login),
    path('logout/',logout),
    path('cart/',cart),
    path('checkout/',checkout),
    path('order/',order)
]