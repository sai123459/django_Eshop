from django.contrib import auth
from django.contrib.auth.hashers import make_password, check_password
from django.http import HttpResponse
from django.shortcuts import render, redirect
from store.models import Product , Category ,Customer,Order

# Create your views here.
from store.middleware.auth import auth_middleware


def index(request):
    if request.method=='POST':
        product_id=request.POST.get('product_id')
        remove=request.POST.get('remove')
        print(product_id)

        cart=request.session.get('cart')
        if cart:
            quantity=cart.get(product_id)
            #print(quantity)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(product_id)
                    else:
                        cart[product_id]=quantity-1
                else:
                    cart[product_id]=quantity+1
            else:
                cart[product_id]=1
        else:
            cart={}
            cart[product_id]=1

        request.session['cart']=cart
        print(request.session.get('cart'))

        return redirect('/')

    else:
        cart=request.session.get('cart')
        if not cart:
            request.session['cart']={}

        products=Product.objects.all()
        category=Category.objects.all()
        category_id=request.GET.get('category')
        print(category_id)
        if category_id :
            products = Product.objects.filter(category=category_id)
            print('your are ',request.session.get('email'))
            return render(request,'index.html',{'products':products,'category':category})
        else:

            return render(request,'index.html',{'products':products,'category':category})


def signup(request):
    if request.method=='GET':
        return render(request, 'signup.html')

    print(request.POST.get('firstname'))
    firstname=request.POST.get('firstname')
    lastname = request.POST.get('lastname')
    phnumber = request.POST.get('phnumber')
    email = request.POST.get('email')
    password = request.POST.get('password')

    # Validations................

    error= None
    if (not firstname):
        error='please enter first name'
    elif len(firstname)<5 :
        error = ' Firstname must be greater than 5 characters '
    elif len(lastname)<5 :
        error = ' lastname must be greater than 5 characters '
    elif len(phnumber)< 10 :
        error = ' Phone number must be 10 numbers  '
    elif Customer.objects.filter(Email=email).exists():
        error = 'Email is already registered '






    # end of validations............
    if (not error):
        customer = Customer(First_name=firstname , Last_name=lastname , Ph_number=phnumber ,Email=email , Password=password)
        customer.Password=make_password(customer.Password)
        print(customer.Password)
        customer.save()
        #return HttpResponse('<h1> welcome ' + firstname + ' , You Registered successfully</h1>')
        return redirect('/')
    else :
        return render(request, 'signup.html',{'error':error})


def login(request):
    if request.method=='GET':
        # pwd=make_password('234')
        # print(pwd)
        # yes=check_password('234',pwd)
        # print(yes)
        return render(request,'login.html')
    email=request.POST.get('email')
    password=request.POST.get('password')
    print(email,password)
    customer=Customer.objects.get(Email=email)
    print(customer)
    print(customer.Password)
    print(customer.First_name)

    error = None
    if customer:
        status=check_password(password,customer.Password)
        if status:
            request.session['customer_id']=customer.id
            request.session['email'] = customer.Email
            request.session['fname']=customer.First_name
            return redirect('/')
        error = 'Invalid email and password'
        # return render(request,'/login.html',{'error':error})
    else:
        error = 'Invalid email and password'
        # return render(request,'/login.html',{'error':error})

    return render(request,'login.html',{'error': error})

def logout(request):
    request.session.clear()
    return redirect('/login')

def cart(request):
    cart=list(request.session.get('cart').keys())
    print(cart)
    # for i in cart:
    product=Product.objects.filter(id__in=cart)

    print(product)

    return render(request,'store/cart.html',{'product':product})

def checkout(request):
    address=request.POST.get('Address')
    phone=request.POST.get('Phone')
    customer=request.session['customer_id']
    cart = request.session.get('cart')
    #print(cart)
    product = Product.objects.filter(id__in=cart)
    #print(product)

    for product in product :

        order= Order(customer=Customer(id=customer),product=product,price=product.price,address=address,phone=phone,
                    quantity=cart.get(str(product.id)))
        order.save()
        request.session['cart']={}

    return redirect('/cart')

@auth_middleware
def order(request):
    customer = request.session['customer_id']
    orders = Order.objects.filter(customer=customer).order_by('-date')
    print(orders)
    return render(request,'store/orders.html',{'orders':orders})